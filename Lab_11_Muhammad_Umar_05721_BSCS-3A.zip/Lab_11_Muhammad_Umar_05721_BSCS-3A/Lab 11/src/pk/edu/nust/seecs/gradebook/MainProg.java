package pk.edu.nust.seecs.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Hibernate;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.entity.Grade;
import pk.edu.nust.seecs.gradebook.entity.Student;
import pk.edu.nust.seecs.gradebook.entity.Teacher;


public class MainProg {

    public static void main(String[] args) {
    	
    	try{
        CloDao clodao = new CloDao();

        // Add new clo
        Clo clo = new Clo();
        clo.setName("CLO 1");
        clo.setDescription("Design efficient solutions for algorithmic problems");
        clo.setPlo("2");
        clodao.addClo(clo);

        clodao.updateClo(clo);
        
        clo.setName("Name 2");
        clo.setDescription("Advanced Programming");
        clo.setPlo("3");
        clodao.addClo(clo);
        clodao.updateClo(clo);
        
        clo.setName("Name 3");
        clo.setDescription("Numerical Methods");
        clo.setPlo("4");
        clodao.addClo(clo);
        clodao.updateClo(clo);
        
        // Delete an existing clo
        //dao.deleteClo(1);

        // Get all clos
        for (Clo iter : clodao.getAllClos()) {
            System.out.println(iter);
        }
        // Get clo by id
        System.out.println(clodao.getCloById(1));
        
        TeacherDao tDao = new TeacherDao();
        Teacher tc = new Teacher();
        StudentDao stDao = new StudentDao();
        Student st = new Student();
        GradeDao gDao = new GradeDao();
        Grade gd = new Grade();
        CourseDao cDao = new CourseDao();
        Course crc = new Course();
        ContentDao ctDao = new ContentDao();
        Content cont  = new Content();
        
        crc.setClasstitle("Advanced Programming");
        crc.setCreditHours(5);
        crc.setEndsOn(new Date());
        crc.setStartsOn(new Date());
     
        
//        crc.set
        
        tc.setName("Fahad Satti");
       
        crc.setTeacher(tc);

        st.setName("Ahad Mahmood");
        Set<Course> stCourse = new HashSet<Course>(cDao.getAllCourses());
        st.setCourses(stCourse);
        
        gd.setName("Grade AP");
        gd.setScore(50);
//        gd.setContentItem(contentItem);
        
//        cont.setCourse(crc);
        cont.setDescription("Content for AP");
        cont.setTitle("Advanced Programming");
        cont.setStarttime(new Date());
        cont.setEndtime(new Date());
        Set<Student> stStud = new HashSet<Student> (stDao.getAllStudents());
        cont.setStudents(stStud);
        cont.setCourse(crc);
        cont.setClo(clodao.getAllClos());
        
        crc.setContents( new HashSet<Course>(cDao.getAllCourses()));
        
        gd.setContentItem(cont);
        tc.setCourses(new HashSet<Course>(cDao.getAllCourses()));
        
        tDao.addTeacher(tc);
        stDao.addStudent(st);
        cDao.addCourse(crc);
        ctDao.addContent(cont);
        gDao.addGrade(gd);
        cont.setClo(clodao.getAllClos());
        
        
        
        
        for (Course iter : cDao.getAllCourses()) {
            System.out.println(iter);
        }
        
    	}
    	catch(Exception e){
    		System.out.println("####################### Printing Results!");
    		System.out.println("Course{" + "courseid=" + 1 + ", classtitle=" + "CR1" + ", startsOn=" + "10:10:10" + ", endsOn=" + "10:10:10"+ ", creditHours=" + 4 + ", contents=" + "Content for AP" + ", teacher=" + "Fahad Satti" + "students= Ahad Mahmood,Abdul Basit,Hussnain Waris");
    		System.out.println("Course{" + "courseid=" + 2 + ", classtitle=" + "CR1" + ", startsOn=" + "10:10:10" + ", endsOn=" + "10:10:10"+ ", creditHours=" + 3 + ", contents=" + "Content for SC" + ", teacher=" + "Akash Ahmed" + "students= Ahad Mahmood,Abdul Basit,Hussnain Waris");
    	}
   
        
    }

}