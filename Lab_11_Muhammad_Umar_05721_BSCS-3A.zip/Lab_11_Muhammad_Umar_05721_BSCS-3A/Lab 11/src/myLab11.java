import java.util.Scanner;
import attendance.ui.AttendanceSystem;
import javax.swing.JFrame;



public class myLab11 
{

	
	String Selection = "";
	String Name_info = "";
	String Course_info = "";
	Scanner Input; 
	
	myLab11()
	
	{

		Input = new Scanner(System.in);
		System.out.println("Select from the following menu ");
		System.out.println("1)Insert Student \n");
		System.out.println("2)Insert Teacher  \n");
		System.out.println("3)Mark Attendance \n");
		Selection = Input.nextLine();
		
		
			if ( Selection.matches("1"))
			
			{
			
			Input = new Scanner (System.in);
			System.out.println("Enter Student Name: ");
			Name_info = Input.next();
			
			System.out.println("Inserting Name into the DB");

			Input = new Scanner(System.in);
			System.out.println("Enter comma seperated courses: ");
			Course_info = Input.nextLine();
			System.out.println("Inserting courses into the BD");
			System.out.println(Name_info);
			System.out.println(Course_info);
				
			}
			
			if ( Selection.matches("2"))
				
			{
			
			Input = new Scanner (System.in);
			System.out.println("Enter Teacher Name: ");
			Name_info = Input.next();
			System.out.println("Inserting teacher name into the DB");
			Input = new Scanner(System.in);
			System.out.println("Enter comma seperated courses: ");
			Course_info = Input.nextLine();
			System.out.println("Inserting courses into the BD");
			System.out.println(Name_info);
			System.out.println(Course_info);
				
			}
			
			
		if(Selection.matches("3"))
		{
			
			AttendanceSystem attend = new AttendanceSystem();;
			attend.setVisible(true);
			attend.setAutoRequestFocus(true);
			attend.setAlwaysOnTop(true);
			attend.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		}
		
		
	}

	public static void main (String []args)
	{
		new myLab11();
	}

}
